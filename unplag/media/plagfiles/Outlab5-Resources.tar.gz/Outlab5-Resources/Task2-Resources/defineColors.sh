BLACK_FONT=`tput setaf 0`
RED_FONT=`tput setaf 1`
GREEN_FONT=`tput setaf 2`
YELLOW_FONT=`tput setaf 3`
BLUE_FONT=`tput setaf 4`
MAGENTA_FONT=`tput setaf 5`
CYAN_FONT=`tput setaf 6`
WHITE_FONT=`tput setaf 7`

BLACK_BACKGROUND=`tput setab 0`
RED_BACKGROUND=`tput setab 1`
GREEN_BACKGROUND=`tput setab 2`
YELLOW_BACKGROUND=`tput setab 3`
BLUE_BACKGROUND=`tput setab 4`
MAGENTA_BACKGROUND=`tput setab 5`
CYAN_BACKGROUND=`tput setab 6`
WHITE_BACKGROUND=`tput setab 7`

RESET_ALL=`tput sgr0`